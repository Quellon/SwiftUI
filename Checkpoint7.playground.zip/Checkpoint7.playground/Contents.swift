import UIKit

class Animal{
    var legs: Int
    
    init(legs: Int) {
        self.legs = legs
    }
    func speak(){
        print("Animal is the soud")
        }
}

class Dog: Animal{
    override func speak(){
        print("Dog is the soud")
        }
}

class Cat:Animal{
    var isTame: Bool
    
     init(legs: Int, isTame:Bool) {
        self.isTame = isTame
        super.init(legs: legs)
        
    }
     override func speak(){
        print("Cat is the sound of Cat")
    }
}

class Corgi: Dog{
   // override init(noise: String, legs: Int) {
   //     super.init(noise: "Woof", legs: 4)
  // }
      //var noise:String =="Woof"
    override func speak() {
        print("Corgi: woof is the sound and has \(legs) legs")
    }
}

class Poodle:Dog{
    override func  speak() {
        print("Poodle: Woof is the sound and has \(legs) legs")
    }
}

class Lion:Cat{
    override func speak() {
        print("Lion: Roar is the sound and has \(legs) legs")
    }
   }

class Persian:Cat{
    override func speak() {
        print("Pesian: Meow is the sound and has \(legs) legs")
    }
}

let c = Corgi(legs: 4)
let p = Poodle(legs: 4)
let l = Lion(legs: 4, isTame: false)
let houseCat = Persian(legs: 4, isTame: true)

print(c.speak())
print(p.speak())
print(l.speak())
print(houseCat.speak())
