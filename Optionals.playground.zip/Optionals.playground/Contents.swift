import UIKit

var myVar: Int? = 3

if let unwrapped = myVar {          //runs the code if there is a value
    print("Run if myVar has a value inside")
}

guard let unwrapped = myVar else {      //runs the code if the is NOT a value
    print("Run if myVar doesn't have a value inside")
    //demands that you exit this function
}




func printSquare(of number: Int?) {
    guard let number = number else {
        print("Missing input")

        // 1: We *must* exit the function here
        return          //NEEDED
    }

    // 2: `number` is still available outside of `guard`
    print("\(number) x \(number) is \(number * number)")
}


// use if let to work with optionals however you wish
//use gaurd let to ensure the optionals have something inside them or bail out


let captains = [
    "Enterprise": "Picard",
    "Voyager": "Janeway",
    "Defiant": "Sisko"
]

let new = captains["Serenity"]  //sets new as an optional

let new = captains["Serenity"] ?? "N/A" //new is not an optional, given value "N/A" if new is nil
let new = captains["Serenity", default: "N/A"]      //same as above (KINDA)


let tvShows = ["Archer", "Babylon 5", "Ted Lasso"]
let favorite = tvShows.randomElement() ?? "None"


struct Book {
    let title: String
    let author: String?
}

let book = Book(title: "Beowulf", author: nil)
let author = book.author ?? "Anonymous"
print(author)


let input = ""
//            optional int
let number = Int(input) ?? 0
print(number)

struct Book {
    let title: String
    let author: String?
}

var book: Book? = nil
//          if we have a book AND an author AND has a first letter then uppercase it
//if not the "A"
let author = book?.author?.first?.uppercased() ?? "A"
print(author)

enum UserError: Error {
    case badID, networkFailed
}

func getUser(id: Int) throws -> String {
    throw UserError.networkFailed
}

if let user = try? getUser(id: 23) {
    print("User: \(user)")
}
//      if a error is thrown it counts as nil
let user = (try? getUser(id: 23)) ?? "Anonymous"
print(user)

//using try will not returnt he value that is presented
