import UIKit

var numbers = 1;

while numbers <= 100{
    if numbers.isMultiple(of: 3) && numbers.isMultiple(of: 5){
        print("FizzBuzz")
    }else if numbers.isMultiple(of: 5){
        print("Buzz")
    }else if numbers.isMultiple(of: 3) {
        print("Fizz")
    }else{
        print(numbers)
    }
    numbers+=1
    
}
