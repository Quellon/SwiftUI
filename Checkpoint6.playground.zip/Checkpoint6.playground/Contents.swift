import UIKit

struct Car{
    var model: String
    var noSeats: Int
    var currentGear: Int
    
    
    init(model: String, noSeats: Int, currentGear: Int) {
        self.model = model
        self.noSeats = noSeats
        self.currentGear = currentGear
    }
    
    mutating func changeGear(shift:String){
        var g: Bool = shift.contains("up")
        if g {
            currentGear = currentGear + 1
        }else{
            currentGear = currentGear - 1
        }
        }
       
    }

var newCar = Car(model: "VW", noSeats: 4, currentGear: 4)
newCar.changeGear(shift: "down")
print(newCar)
