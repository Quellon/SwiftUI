import UIKit
//creates array
var names: [String] = ["chris", "chris","barry", "katherine"]

names.count
//prints number of indexes in array
print(names.count)
//converts the array into a new set --> gets rid of duplicates
var newArr = Set(names)
print(newArr)
