import UIKit

extension String {
    func trimmed() -> String {
        self.trimmingCharacters(in: .whitespacesAndNewlines)
    }
}

var quote = "   The truth is rarely pure and never simple   "
let trimmed = quote.trimmed()


struct Book {
    let title: String
    let pageCount: Int
    let readingHours: Int

    
    init(title: String, pageCount: Int) {
        self.title = title
        self.pageCount = pageCount
        self.readingHours = pageCount / 50
    }
}

let b = Book(title: "", pageCount: 4, readingHours: 5)
//notice you cannot add a value for readingHours - the custome initializer gives a value
// therefor, takes away the ability to initialize a vlaue upon creation
//if the custom initializer did not giva a value this possible

//Using an extension, you are able to have a custom initializer and still
//manipulate all values

struct Book1{
    let title: String
    let pageCount: Int
    let readingHours: Int
    
}
extension Book1{
    init(title: String, pageCount: Int){
        self.title = title
        self.pageCount = pageCount
        self.readingHours = pageCount/50
    }
}

let Books = Book1(title: <#T##String#>, pageCount: <#T##Int#>)
let books = Book1(title: <#T##String#>, pageCount: <#T##Int#>, readingHours: <#T##Int#>)

//NOTICE
//Swift gives me the option to manipulate all values or leave the initialized ones.


protocol Person{
    var name: String {get}
    func sayHello()
}
extension Person{
    func sayHello(){
        print("\(name) says hello")
    }
}
struct Employee: Person{        //if the extension wasnt there, you will eed to add a func syaHello
    let name: String
}
let taylor = Employee(name: "Taylor")
taylor.sayHello()
