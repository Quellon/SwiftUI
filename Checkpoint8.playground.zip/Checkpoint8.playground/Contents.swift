import UIKit

protocol building{
    var rooms: Int {get}
    var cost: Int {get}
    var name: String {get}
    func summary()
}
extension building{
    func summary(){
        print("Number of rooms: \(rooms) \nCost of Property: \(cost) \nName of realtor: \(name)")
    }
}

struct House: building{
    let rooms: Int
    let cost: Int
    let name: String
}

struct Office: building{
    let rooms:Int
    let cost:Int
    let name:String
}


let h = House(rooms: 4, cost: 500_000, name: "James")
h.summary()

let o = Office(rooms: 6, cost: 1_000_000, name: "Catalyst")
o.summary()
