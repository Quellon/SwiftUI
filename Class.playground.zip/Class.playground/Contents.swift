import UIKit

class User {
    var username = "Anonymous"
}
var user1 = User()

var user2 = user1
user2.username = "Taylor"

print(user1.username)
print(user2.username)

class User1 {
    var username = "Anonymous"

    func copy() -> User1 {
        let user = User1()
        user.username = username
        return user
    }
}


var users = User1()
print(users.copy().username)
users.username = "name"
print(users.username)
var m = users.copy()
print(m)
print(users.copy())

