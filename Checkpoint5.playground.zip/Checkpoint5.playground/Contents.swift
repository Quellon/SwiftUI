import UIKit

let luckyNumbers = [7, 4, 38, 21, 16, 15, 12, 33, 31, 49]

var calc = {(clone: [Int]) in
    clone.filter{!$0.isMultiple(of: 2)}
        .sorted()
        .map{print("\($0) is a lucky number")}
}
calc(luckyNumbers)

//Everything else id wrong!!!!!!!!!
let output = { (numberArr:[Int]) -> Bool in
   var newNum: [Int] =  []
    luckyNumbers.sorted()
    for x in luckyNumbers{
        if x.isMultiple(of: 2){
           newNum.append(x)
            return true
        }else{
            return false
        }
    }
   
   return true
}
print(output)

let new = luckyNumbers.sorted(by:{ (numbers: Int, number: Int) -> Bool in
    
   
    if numbers.isMultiple(of: 2){
       //print( "\(numbers) is a lucky number")
        print( "\(numbers) is a lucky number")
        return true
    }else{
        return false
    }
    
})

print(new)

print(luckyNumbers)

let t = luckyNumbers.filter{$0.isMultiple(of: 2)}.sorted()
t.forEach{print("\($0) is a lucky number")}
//map {"\($0) is a lucky number"}
//"\(x) is a lucky number

//let n = luckyNumbers.contains()

