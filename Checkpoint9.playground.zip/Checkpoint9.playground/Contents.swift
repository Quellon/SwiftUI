import UIKit


func prac(numbers: [Int]?) -> Int{
    return numbers?.randomElement() ?? Int.random(in: 1...100)
}
var prac1 = {(numbers:[Int]?) -> Int in return numbers?.randomElement() ?? Int.random(in: 1...100)}
