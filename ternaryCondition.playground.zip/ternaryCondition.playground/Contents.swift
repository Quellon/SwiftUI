import UIKit

let age = 18
let canVote = age >= 18 ? "Yes" : "No"


enum Theme {
    case light, dark
}

let theme = Theme.dark
                                //Yes          NO
let background = theme == .dark ? "black" : "white"
print(background)
