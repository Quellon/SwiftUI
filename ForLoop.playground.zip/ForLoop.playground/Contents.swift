import UIKit

let platforms = ["iOS", "macOS", "tvOS", "watchOS"]

for os in platforms {
    print("Swift works great on \(os).")
}


for i in 1...5 {
    print("Counting from 1 through 5: \(i)")
}

print()

for i in 1..<5 {            //stops at 4
    print("Counting 1 up to 5: \(i)")
}


//used to reeat print a line --> no other operations used
var lyric = "Haters gonna"

for _ in 1...5 {
    lyric += " hate"
}

print(lyric)


let names = ["Piper", "Alex", "Suzanne", "Gloria"]
print(names[0...3])     //if the array does not have atleast 4 indexes it would fail
print(names[1...])  //using a 1 sided range fixes that
