import UIKit

enum checkpointError: Error{
    case outOfBounds,noRoot
}

var root: Int = 0

func calc(number: Int)throws -> Int{
    
        if number < 1{
            throw checkpointError.outOfBounds
        }else if number > 10000{
            throw checkpointError.outOfBounds
        }else{
            for x in 1...number{
                if (x * x == number){
                    root = x
                    print("The square root of \(number) is: \(root)")
                }
            }
        }
    return root
    }

try calc(number: 10000)
