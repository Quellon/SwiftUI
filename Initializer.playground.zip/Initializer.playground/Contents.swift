import UIKit


struct Player {
    let name: String
    let number: Int
}

let player = Player(name: "Megan R", number: 15)


struct Player {
    let name: String
    let number: Int

    init(name: String, number: Int) {   //must initialize all!!
        //name prop the name that is in my method (INIT)
        self.name = name
        self.number = number
    }
}


struct Player {
    let name: String
    let number: Int

    init(name: String) {        //custom
        self.name = name
        number = Int.random(in: 1...99)
    }
}

let player = Player(name: "Megan R")
print(player.number)
