import UIKit

func greetUser() {
    print("Hi there!")
}

greetUser()

var greetCopy = greetUser
greetCopy()

let sayHello = { (name: String) -> String in   //in is the start of the first curly bracket
    "Hi \(name)!"
}

func getUserData(for id: Int) -> String {
    if id == 1989 {
        return "Taylor Swift"
    } else {
        return "Anonymous"
    }
}

//       parameter  return type
let data: (Int) -> String = getUserData //Accepts int and returns string
// notice - no parameter name needed for closure
let user = data(1989)
print(user)


let team = ["Gloria", "Suzanne", "Piper", "Tiffany", "Tasha"]
let sortedTeam = team.sorted()
print(sortedTeam)


//func captainFirstSorted(name1: String, name2: String) -> Bool {
 //   if name1 == "Suzanne" {
//        return true
 //   } else if name2 == "Suzanne" {
 //       return false
//    }
//
//    return name1 < name2
//}
//let captainFirstTeam = team.sorted(by: captainFirstSorted)
//print(captainFirstTeam)

//Re-create above code using closesure
let captainFirstTeam = team.sorted(by:{(name1: String, name2: String) -> Bool in
    if name1 == "Suzanne"{
        return true
    }else if name2 == "Suzanne"{
        return false
    }
    return name1 < name2
})



let tonly = team.filter{$0.hasPrefix("T")}
print(tonly)
